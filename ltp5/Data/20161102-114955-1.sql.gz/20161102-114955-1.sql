-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : lunhui_tp5
-- 
-- Part : #1
-- Date : 2016-11-02 11:49:55
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `think_admin`
-- -----------------------------
DROP TABLE IF EXISTS `think_admin`;
CREATE TABLE `think_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '用户名',
  `password` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '密码',
  `loginnum` int(11) DEFAULT '0' COMMENT '登陆次数',
  `last_login_ip` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '最后登录IP',
  `last_login_time` int(11) DEFAULT '0' COMMENT '最后登录时间',
  `real_name` varchar(255) COLLATE utf8_bin DEFAULT '' COMMENT '真实姓名',
  `status` int(1) DEFAULT '0' COMMENT '状态',
  `groupid` int(11) DEFAULT '1' COMMENT '用户角色id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- -----------------------------
-- Records of `think_admin`
-- -----------------------------
INSERT INTO `think_admin` VALUES ('1', 'admin', 'ebbd202c239d6fc65061ae22a13c1b69', '174', '127.0.0.1', '1478056439', 'admin', '1', '1');
INSERT INTO `think_admin` VALUES ('13', 'test', 'a69e14096f597b30a116cc7ed206100b', '0', '', '0', 'bfg', '1', '2');
INSERT INTO `think_admin` VALUES ('15', 'test123', 'ebbd202c239d6fc65061ae22a13c1b69', '0', '', '0', 'dddd', '1', '3');

-- -----------------------------
-- Table structure for `think_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group`;
CREATE TABLE `think_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `rules` char(80) NOT NULL DEFAULT '',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group`
-- -----------------------------
INSERT INTO `think_auth_group` VALUES ('1', '超级管理员', '1', '', '1446535750', '1446535750');
INSERT INTO `think_auth_group` VALUES ('2', '内容管理员', '1', '1,2,9,10,11,12,3,4,5,6,7,8', '1446535750', '1446535750');
INSERT INTO `think_auth_group` VALUES ('3', '系统维护员', '1', '1,2,9,10,11,12,3,4,5,6,7,8', '1446535750', '1446535750');
INSERT INTO `think_auth_group` VALUES ('4', '工程部', '1', '1,2,9,10,11,12,3,4,5,6,7,8', '1446535750', '1446535750');

-- -----------------------------
-- Table structure for `think_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_group_access`;
CREATE TABLE `think_auth_group_access` (
  `uid` mediumint(8) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_group_access`
-- -----------------------------
INSERT INTO `think_auth_group_access` VALUES ('1', '1');
INSERT INTO `think_auth_group_access` VALUES ('9', '2');
INSERT INTO `think_auth_group_access` VALUES ('14', '3');

-- -----------------------------
-- Table structure for `think_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `think_auth_rule`;
CREATE TABLE `think_auth_rule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `css` varchar(20) NOT NULL COMMENT '样式',
  `condition` char(100) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_auth_rule`
-- -----------------------------
INSERT INTO `think_auth_rule` VALUES ('1', '#', '系统管理', '1', '1', 'fa fa-gear', '', '0', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('2', 'admin/user/index', '用户管理', '1', '1', '', '', '1', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('3', 'admin/role/index', '角色管理', '1', '1', '', '', '1', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('4', 'admin/menu/index', '菜单管理', '1', '1', '', '', '1', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('5', '#', '数据库管理', '1', '1', 'fa fa-database', '', '0', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('6', 'admin/data/index', '数据备份/还原', '1', '1', '', '', '5', '0', '1446535750', '');
INSERT INTO `think_auth_rule` VALUES ('7', 'admin/data/importdata', '备份数据', '1', '1', '', '', '6', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('8', 'admin/data/backdata', '还原数据', '1', '1', '', '', '6', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('9', 'admin/user/useradd', '添加用户', '1', '1', '', '', '2', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('10', 'admin/user/useredit', '编辑用户', '1', '1', '', '', '2', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('11', 'admin/user/userdel', '删除用户', '1', '1', '', '', '2', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('12', 'admin/user/user_state', '用户状态更改', '1', '1', '', '', '2', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('13', '#', '日志管理', '1', '1', 'fa fa-tasks', '', '0', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('14', 'admin/log/operate_log', '操作日志', '1', '1', '', '', '13', '0', '0', '');
INSERT INTO `think_auth_rule` VALUES ('22', '7', '天堂海滩', '1', '0', '', '', '13', '50', '0', '');

-- -----------------------------
-- Table structure for `think_log`
-- -----------------------------
DROP TABLE IF EXISTS `think_log`;
CREATE TABLE `think_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `admin_name` varchar(50) DEFAULT NULL COMMENT '用户姓名',
  `description` varchar(300) DEFAULT NULL COMMENT '描述',
  `ip` char(60) DEFAULT NULL COMMENT 'IP地址',
  `status` tinyint(1) DEFAULT NULL COMMENT '1 成功 2 失败',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=260 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_log`
-- -----------------------------
INSERT INTO `think_log` VALUES ('146', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477067453');
INSERT INTO `think_log` VALUES ('147', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477067743');
INSERT INTO `think_log` VALUES ('148', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477067880');
INSERT INTO `think_log` VALUES ('149', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477068084');
INSERT INTO `think_log` VALUES ('150', '1', 'admin', '用户【admin】登录失败：验证码错误', '0.0.0.0', '2', '1477068155');
INSERT INTO `think_log` VALUES ('151', '1', 'admin', '用户【admin】登录失败：密码错误', '0.0.0.0', '2', '1477068161');
INSERT INTO `think_log` VALUES ('152', '1', 'admin', '用户【admin】登录失败：验证码错误', '0.0.0.0', '2', '1477068166');
INSERT INTO `think_log` VALUES ('153', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477068172');
INSERT INTO `think_log` VALUES ('154', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477068497');
INSERT INTO `think_log` VALUES ('155', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068668');
INSERT INTO `think_log` VALUES ('156', '', 'tjl', '用户【tjl】登录失败：密码错误', '0.0.0.0', '2', '1477068701');
INSERT INTO `think_log` VALUES ('157', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068713');
INSERT INTO `think_log` VALUES ('158', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068785');
INSERT INTO `think_log` VALUES ('159', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068837');
INSERT INTO `think_log` VALUES ('160', '9', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068859');
INSERT INTO `think_log` VALUES ('161', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477068896');
INSERT INTO `think_log` VALUES ('162', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477068930');
INSERT INTO `think_log` VALUES ('163', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068945');
INSERT INTO `think_log` VALUES ('164', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477068967');
INSERT INTO `think_log` VALUES ('165', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477069125');
INSERT INTO `think_log` VALUES ('166', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477069183');
INSERT INTO `think_log` VALUES ('167', '1', 'admin', '用户【admin】登录失败：密码错误', '0.0.0.0', '2', '1477069400');
INSERT INTO `think_log` VALUES ('168', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477069409');
INSERT INTO `think_log` VALUES ('169', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477069665');
INSERT INTO `think_log` VALUES ('170', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477069984');
INSERT INTO `think_log` VALUES ('171', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477070633');
INSERT INTO `think_log` VALUES ('172', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477070686');
INSERT INTO `think_log` VALUES ('173', '1', 'admin', '会员ID=212061删除成功', '0.0.0.0', '1', '1477070722');
INSERT INTO `think_log` VALUES ('174', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477071040');
INSERT INTO `think_log` VALUES ('175', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477071363');
INSERT INTO `think_log` VALUES ('176', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477071420');
INSERT INTO `think_log` VALUES ('177', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477071783');
INSERT INTO `think_log` VALUES ('178', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477072166');
INSERT INTO `think_log` VALUES ('179', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477072235');
INSERT INTO `think_log` VALUES ('180', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477072253');
INSERT INTO `think_log` VALUES ('181', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477073747');
INSERT INTO `think_log` VALUES ('182', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477073780');
INSERT INTO `think_log` VALUES ('183', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477073905');
INSERT INTO `think_log` VALUES ('184', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477073941');
INSERT INTO `think_log` VALUES ('185', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477074048');
INSERT INTO `think_log` VALUES ('186', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477075118');
INSERT INTO `think_log` VALUES ('187', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477075798');
INSERT INTO `think_log` VALUES ('188', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477075834');
INSERT INTO `think_log` VALUES ('189', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477076807');
INSERT INTO `think_log` VALUES ('190', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477076848');
INSERT INTO `think_log` VALUES ('191', '1', 'admin', '用户【admin】登录失败：验证码错误', '0.0.0.0', '2', '1477077463');
INSERT INTO `think_log` VALUES ('192', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477077499');
INSERT INTO `think_log` VALUES ('193', '1', 'tjl', '用户【tjl】登录失败：密码错误', '0.0.0.0', '2', '1477077940');
INSERT INTO `think_log` VALUES ('194', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477077949');
INSERT INTO `think_log` VALUES ('195', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477078148');
INSERT INTO `think_log` VALUES ('196', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477078356');
INSERT INTO `think_log` VALUES ('197', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477078469');
INSERT INTO `think_log` VALUES ('198', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477078849');
INSERT INTO `think_log` VALUES ('199', '1', 'admin', '用户【admin】登录失败：密码错误', '0.0.0.0', '2', '1477079477');
INSERT INTO `think_log` VALUES ('200', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477079486');
INSERT INTO `think_log` VALUES ('201', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477079795');
INSERT INTO `think_log` VALUES ('202', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477081860');
INSERT INTO `think_log` VALUES ('203', '1', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477081908');
INSERT INTO `think_log` VALUES ('204', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477082119');
INSERT INTO `think_log` VALUES ('205', '', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477113553');
INSERT INTO `think_log` VALUES ('206', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477126766');
INSERT INTO `think_log` VALUES ('207', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477126902');
INSERT INTO `think_log` VALUES ('237', '', 'admin', '用户ID=12删除成功', '0.0.0.0', '1', '1477236865');
INSERT INTO `think_log` VALUES ('209', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477127087');
INSERT INTO `think_log` VALUES ('210', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477127263');
INSERT INTO `think_log` VALUES ('211', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477127345');
INSERT INTO `think_log` VALUES ('236', '1', 'admin', '用户【admin】删除管理员成功(ID=12)', '0.0.0.0', '1', '1477236865');
INSERT INTO `think_log` VALUES ('213', '1', 'admin', '用户【admin】编辑网点成功', '0.0.0.0', '1', '1477135346');
INSERT INTO `think_log` VALUES ('214', '1', 'admin', '用户【admin】编辑菜单成功', '0.0.0.0', '1', '1477135395');
INSERT INTO `think_log` VALUES ('215', '1', 'admin', '用户【admin】编辑菜单成功', '0.0.0.0', '1', '1477135407');
INSERT INTO `think_log` VALUES ('216', '1', 'admin', '用户【admin】编辑菜单成功', '0.0.0.0', '1', '1477135785');
INSERT INTO `think_log` VALUES ('217', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477135910');
INSERT INTO `think_log` VALUES ('218', '', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477139864');
INSERT INTO `think_log` VALUES ('219', '', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477140396');
INSERT INTO `think_log` VALUES ('220', '', 'tjl', '用户【tjl】登录成功', '0.0.0.0', '1', '1477140627');
INSERT INTO `think_log` VALUES ('221', '', 'admin', '用户【admin】登录失败：密码错误', '0.0.0.0', '2', '1477146841');
INSERT INTO `think_log` VALUES ('238', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477237685');
INSERT INTO `think_log` VALUES ('235', '', 'admin', '用户【25424】添加成功', '0.0.0.0', '1', '1477236845');
INSERT INTO `think_log` VALUES ('225', '', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477230873');
INSERT INTO `think_log` VALUES ('226', '1', 'admin', '用户【admin】添加菜单成功', '0.0.0.0', '1', '1477231502');
INSERT INTO `think_log` VALUES ('227', '1', 'admin', '用户【admin】编辑菜单成功', '0.0.0.0', '1', '1477231523');
INSERT INTO `think_log` VALUES ('228', '1', 'admin', '用户【admin】编辑菜单成功', '0.0.0.0', '1', '1477231727');
INSERT INTO `think_log` VALUES ('229', '', 'admin', '用户【54254】添加成功', '0.0.0.0', '1', '1477233585');
INSERT INTO `think_log` VALUES ('230', '', 'admin', '用户【54254】编辑成功', '0.0.0.0', '1', '1477233968');
INSERT INTO `think_log` VALUES ('231', '', 'admin', '用户【7777】编辑成功', '0.0.0.0', '1', '1477233978');
INSERT INTO `think_log` VALUES ('232', '', 'admin', '用户【7777】添加成功', '0.0.0.0', '1', '1477233993');
INSERT INTO `think_log` VALUES ('233', '', 'admin', '用户【7777】添加成功', '0.0.0.0', '1', '1477233995');
INSERT INTO `think_log` VALUES ('239', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477269102');
INSERT INTO `think_log` VALUES ('240', '1', 'admin', '用户【admin】删除菜单成功', '0.0.0.0', '1', '1477269144');
INSERT INTO `think_log` VALUES ('241', '1', 'admin', '用户【admin】删除菜单成功', '0.0.0.0', '1', '1477269150');
INSERT INTO `think_log` VALUES ('242', '1', 'admin', '用户【admin】删除菜单成功', '0.0.0.0', '1', '1477269155');
INSERT INTO `think_log` VALUES ('243', '1', 'admin', '用户【admin】删除菜单成功', '0.0.0.0', '1', '1477269161');
INSERT INTO `think_log` VALUES ('244', '1', 'admin', '用户【admin】删除菜单成功', '0.0.0.0', '1', '1477269166');
INSERT INTO `think_log` VALUES ('245', '', 'admin', '用户【test】添加成功', '0.0.0.0', '1', '1477270874');
INSERT INTO `think_log` VALUES ('246', '13', 'test', '用户【test】登录失败：密码错误', '0.0.0.0', '2', '1477271853');
INSERT INTO `think_log` VALUES ('247', '13', 'test', '用户【test】登录失败：密码错误', '0.0.0.0', '2', '1477271870');
INSERT INTO `think_log` VALUES ('248', '', 'admin', '用户【zzj】添加成功', '0.0.0.0', '1', '1477272026');
INSERT INTO `think_log` VALUES ('249', '14', 'zzj', '用户【zzj】登录成功', '0.0.0.0', '1', '1477272040');
INSERT INTO `think_log` VALUES ('250', '1', 'admin', '用户【admin】登录失败：密码错误', '0.0.0.0', '2', '1477275426');
INSERT INTO `think_log` VALUES ('251', '14', 'zzj', '用户【zzj】登录成功', '0.0.0.0', '1', '1477275494');
INSERT INTO `think_log` VALUES ('252', '14', 'zzj', '用户【zzj】登录成功', '0.0.0.0', '1', '1477275599');
INSERT INTO `think_log` VALUES ('253', '', 'zzj', '用户【test123】添加成功', '0.0.0.0', '1', '1477275714');
INSERT INTO `think_log` VALUES ('254', '1', 'admin', '用户【admin】登录成功', '0.0.0.0', '1', '1477275742');
INSERT INTO `think_log` VALUES ('255', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1477736148');
INSERT INTO `think_log` VALUES ('256', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1478055795');
INSERT INTO `think_log` VALUES ('257', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1478056424');
INSERT INTO `think_log` VALUES ('258', '1', 'admin', '用户【admin】登录成功', '127.0.0.1', '1', '1478056439');
INSERT INTO `think_log` VALUES ('259', '1', 'admin', '用户【admin】删除管理员成功(ID=9)', '127.0.0.1', '1', '1478057047');

-- -----------------------------
-- Table structure for `think_member`
-- -----------------------------
DROP TABLE IF EXISTS `think_member`;
CREATE TABLE `think_member` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) DEFAULT NULL COMMENT '邮件或者手机',
  `password` char(32) DEFAULT NULL,
  `face` varchar(128) DEFAULT NULL COMMENT '头像',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `money` int(11) DEFAULT '0' COMMENT '账户余额',
  `reg_time` int(11) DEFAULT '0' COMMENT '注册时间',
  `reg_ip` varchar(15) DEFAULT NULL COMMENT '注册IP',
  `last_time` int(11) DEFAULT NULL COMMENT '最后一次登录',
  `last_ip` varchar(15) DEFAULT NULL COMMENT '最后一次登录IP',
  `status` tinyint(1) DEFAULT NULL COMMENT '1激活  0 未激活',
  `closed` tinyint(1) DEFAULT '0',
  `mobile` varchar(11) DEFAULT NULL COMMENT '认证的手机号码',
  `token` char(32) DEFAULT '0' COMMENT '令牌',
  `session_id` varchar(20) DEFAULT NULL,
  `sex` int(10) DEFAULT NULL COMMENT '1男2女',
  `birthday` varchar(255) DEFAULT NULL,
  `open_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM AUTO_INCREMENT=212065 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `think_member`
-- -----------------------------
INSERT INTO `think_member` VALUES ('212061', '1217037610', 'd41d8cd98f00b204e9800998ecf8427e', '', 'XiMi丶momo', '300', '200', '1476779394', '0.0.0.0', '1476779394', '0.0.0.0', '1', '1', '18809321956', '0', '', '2', '1997-10-17', '');
INSERT INTO `think_member` VALUES ('1', '18809321929', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476762873/1321.jpg', '醉凡尘丶Wordly', '92960', '73', '1476762875', '0.0.0.0', '1476762875', '0.0.0.0', '1', '0', '18809321929', '0', '', '1', '2016-10-17', '');
INSERT INTO `think_member` VALUES ('212039', '1217037610', 'd41d8cd98f00b204e9800998ecf8427e', '', '紫陌轩尘', '400', '434', '1476676516', '0.0.0.0', '1476676516', '0.0.0.0', '1', '1', '49494', '0', '', '1', '2021-10-13', '');
INSERT INTO `think_member` VALUES ('212044', '', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476425832/1464073670790.jpg', 'fag', '24', '424', '1476425833', '0.0.0.0', '1476425833', '0.0.0.0', '', '1', '242', '0', '', '1', '1995-10-27', '');
INSERT INTO `think_member` VALUES ('212045', '18809321928', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476676463/1464073638442.jpg', '空谷幽兰', '53', '3636', '1476676464', '0.0.0.0', '1476676464', '0.0.0.0', '1', '0', '3636', '0', '', '2', '2016-10-13', '');
INSERT INTO `think_member` VALUES ('212049', '', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476425748/20160624012046361.jpg', '787367373', '414', '9', '1476425750', '0.0.0.0', '1476425750', '0.0.0.0', '', '1', '73737373', '0', '', '1', '2003-10-13', '');
INSERT INTO `think_member` VALUES ('212051', '18809321929', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476692253/215358np33w7nw7u4o4536.jpg', 'XMi丶呵呵', '373373', '33', '1476692255', '0.0.0.0', '1476692255', '0.0.0.0', '1', '0', '73', '0', '', '2', '1995-10-14', '');
INSERT INTO `think_member` VALUES ('212052', '1246470984', 'd41d8cd98f00b204e9800998ecf8427e', 'uploads/face/1476692121/1464073670790.jpg', 'XY', '7383', '73737373', '1476692123', '0.0.0.0', '1476692123', '0.0.0.0', '1', '1', '7373', '0', '', '1', '2011-10-14', '');
INSERT INTO `think_member` VALUES ('212053', '18793189097', 'd41d8cd98f00b204e9800998ecf8427e', '', '25773', '7373737', '77', '1476433452', '0.0.0.0', '1476433452', '0.0.0.0', '1', '1', '7373733', '0', '', '1', '2016-10-10', '');
INSERT INTO `think_member` VALUES ('212060', '1246470984', 'e10adc3949ba59abbe56e057f20f883e', 'uploads/face/1476694804/20090106103716418.jpg', 'XiYu', '100', '100', '1476694831', '0.0.0.0', '1476694831', '0.0.0.0', '1', '1', '18793189091', '0', '', '2', '1996-10-17', '');
INSERT INTO `think_member` VALUES ('212064', '', '', 'http://wx.qlogo.cn/mmopen/WS5af6DwbzhvoKlOnV589huTP4nBWhMAEVzVI4gdCUQF0Kpc3FVXrkibWudHhYch2hPaXI4Jrs4ibppBGlSquM4x7abIdibnHgf/0', '烟勤话少脾气好', '0', '0', '0', '', '', '', '', '0', '', '0', '', '', '', 'o0n73s5lR1WClmv3ujC0XU22IRnc');
